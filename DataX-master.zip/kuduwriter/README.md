# datax-kudu-plugin
datax kudu的writer插件



仅在kudu11进行过测试
